[CmdletBinding()]
param(
    [string]$Executable = "tools\twomore-cli.exe",
    [string]$OutputDir = ""
)

$ErrorActionPreference = "Stop"

if (-not [System.IO.Path]::IsPathRooted($Executable)) {
    $fromCurrentDirectory = Join-Path (Get-Location) $Executable
    $fromScriptDirectory = Join-Path $PSScriptRoot $Executable
    $Executable = if (Test-Path -LiteralPath $fromCurrentDirectory -PathType Leaf) {
        $fromCurrentDirectory
    } else {
        $fromScriptDirectory
    }
}
$Executable = (Resolve-Path -LiteralPath $Executable).Path
$appDir = Split-Path -Parent $Executable

if ([string]::IsNullOrWhiteSpace($OutputDir)) {
    $OutputDir = Join-Path $appDir ("support-bundle-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
} elseif (-not [System.IO.Path]::IsPathRooted($OutputDir)) {
    $OutputDir = Join-Path (Get-Location) $OutputDir
}
$OutputDir = [System.IO.Path]::GetFullPath($OutputDir)
if (Test-Path -LiteralPath $OutputDir) {
    throw "Output directory already exists: $OutputDir"
}
New-Item -ItemType Directory -Path $OutputDir | Out-Null

try {
    $diagnostics = Join-Path $OutputDir "twomore-diagnostics.json"
    & $Executable diagnose $diagnostics | Out-Null
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $diagnostics -PathType Leaf)) {
        throw "The application could not export diagnostics."
    }
    $diagnosticsObject = Get-Content -LiteralPath $diagnostics -Raw | ConvertFrom-Json

    # Portable mode keeps logs beside the executable. Installed mode uses the
    # same APPDATA location as the GUI. Never copy settings or device presets.
    $dataCandidates = @(
        $appDir,
        (Join-Path ([Environment]::GetFolderPath("ApplicationData")) "TwoMore")
    ) | Select-Object -Unique
    foreach ($candidate in $dataCandidates) {
        foreach ($name in @("twomore.log", "twomore.log.1", "twomore.log.2", "twomore.log.3", "twomore-test-report.json")) {
            $source = Join-Path $candidate $name
            if (Test-Path -LiteralPath $source -PathType Leaf) {
                Copy-Item -LiteralPath $source -Destination (Join-Path $OutputDir $name)
            }
        }
    }

    $files = Get-ChildItem -LiteralPath $OutputDir -File | Sort-Object Name |
        ForEach-Object {
            [ordered]@{
                name = $_.Name
                bytes = $_.Length
                sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            }
        }
    [ordered]@{
        schema_version = 1
        product = "TwoMore Audio"
        app_version = [string]$diagnosticsObject.app_version
        build_commit = [string]$diagnosticsObject.build_commit
        generated_utc = [DateTime]::UtcNow.ToString("o")
        files = @($files)
        included = @("diagnostics", "test report when present", "bounded application logs")
        excluded = @("settings", "selected endpoint identities", "device control presets", "audio samples", "source code")
        privacy_notice = "Review device names and endpoint IDs before sharing this bundle publicly."
    } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $OutputDir "manifest.json") -Encoding utf8

    Write-Host "Support bundle written to $OutputDir"
    Write-Host "Review device names and endpoint IDs in the bundle before sharing it."
} catch {
    if (Test-Path -LiteralPath $OutputDir) { Remove-Item -LiteralPath $OutputDir -Recurse -Force }
    throw
}
