# Architecture

## Decision

TwoMore Audio uses a C++20 user-mode core on MMDevice and WASAPI with a native
Win32, Direct2D, and DirectWrite desktop shell. This provides direct lifecycle
and HRESULT control, high-DPI Unicode rendering, no runtime package dependency,
and straightforward reuse from both GUI and CLI.

## Data path

```text
GUI cards or CLI selection
    -> WinRT Bluetooth association endpoints + MMDevice inventory
    -> container-ID/name correlation and physical-device grouping
    -> guided readiness, stable pair preset, and endpoint validation
    -> AudioSource (test signal, decoded PCM WAV, or virtual-cable capture)
       -> shared-mode renderer A -> Windows engine -> endpoint A
       -> shared-mode renderer B -> Windows engine -> endpoint B
       -> shared-mode renderer N -> Windows engine -> endpoint N
```

Sources are normalized to a 48 kHz stereo float timeline. Each renderer reads
the common timeline through a phase-continuous four-point Catmull–Rom
micro-resampler, applies software gain and startup delay, and follows its
endpoint's clock with a bounded ppm servo. Live capture uses the same renderer
path as WAV and generated signals. A large scheduler stall may trigger one
counted skip-ahead recovery; normal drift is absorbed without dropping or
duplicating audible samples.

## Modules

- `audio_endpoint`: discovery, filters, grouping, Bluetooth readiness, mock
  devices, stable IDs, and JSON diagnostics.
- `bluetooth_device`: C++/WinRT Bluetooth audio discovery and its correlation
  with MMDevice endpoints, including synthetic pending cards.
- `text`: strict UTF-8/UTF-16 conversion at every narrow/wide boundary.
- `log_buffer`: visible-log deduplication and bounded retention policy.
- `audio_source`: lifecycle-aware source abstraction and generated/file
  implementations.
- `systemwide`: virtual-cable discovery and setup validation, event-driven
  WASAPI capture, PCM conversion, shared capture timeline, latency policies,
  quality/stability models, and deterministic mocks.
- `system_info`: runtime Windows product, display version, build, and UBR
  detection.
- `product_workflows`: reliable-test settings, stable pair identity/presets,
  guided verdicts, virtual-cable detection, and verified configuration records.
- `device_watcher`: `IMMNotificationClient` bridge for endpoint and default
  changes.
- `wave_file`: bounded RIFF parser for PCM16/24/32 and float32 mono/stereo.
- `wasapi_tone_renderer`: cancellable, event-driven shared streams, source
  sampling, gain/delay, disconnect containment, buffer/underrun/drift telemetry,
  soft resynchronization, and HRESULT reporting.
- `audio_math`: portable gain and delay primitives.
- `main`: safe CLI filtering, selection, helpers, WAV/tone transport, and
  actionable errors.
- `gui_main`: Direct2D view, device-card interaction, background jobs, settings,
  logs, system actions, and demo/smoke mode.

## Thread and event model

```text
MMDevice callback -> 300 ms debounce -> background merged enumeration
                                      -> WM_ENDPOINTS_READY -> UI model/render

UI transport -> background source + WASAPI workers
             -> atomic cancellation
             -> WM_RENDER_TELEMETRY -> live quality model/render
             -> WM_SESSION_READY -> UI status and activity log
```

The UI thread never waits for audio. Completed immutable result sets return via
window messages. Closing the application cancels and joins the active session
before COM and rendering resources are released.

The reliable test schedules one shared source timeline:

```text
open endpoints -> low-level warm-up -> burst 1 -> gap -> burst 2 -> gap -> burst 3
                      | renderer-start/stop events update each card |
                                      -> renderer results -> audible confirmation
```

Renderer success and audible success are separate facts. The guided verdict is
SUCCESS only when every renderer wrote buffers without error and the user
confirmed both headphones.

## Stable alignment presets

Each endpoint identity prefers the WinRT Bluetooth device ID, then MMDevice
container ID, then endpoint ID. Sorted identities are hashed into an
order-independent pair key. Presets store delay by identity, so volatile list
indexes and selection order do not affect restoration.

## System-wide path

```text
application audio -> Windows default output = user-installed virtual cable
                  -> VirtualCableSource (shared WASAPI capture)
                  -> PCM/float conversion and 48 kHz stereo timeline
                  -> renderer A -> Bluetooth Media endpoint A
                  -> renderer B -> Bluetooth Media endpoint B
```

Setup validation requires the cable playback endpoint to be the Windows default,
exactly two active real Media outputs, explicit local-capture acknowledgement,
and no cable endpoint among the destinations. Capture/render identity and cable
family loops are rejected to prevent feedback or echo. VB-Cable and Voicemeeter
are detected by endpoint name only and remain separately installed products.
Nothing is bundled or installed by TwoMore. Apps using exclusive mode, protected
content paths, or a manually selected non-default output may bypass the cable.

Cable pairing normalizes direction words while retaining variant tokens, so
standard and 16-channel VB endpoints cannot be paired merely because they share
the broad VB-Cable family. The chosen capture endpoint is reopened by its opaque
MMDevice ID. Capture initialization tries the mix format first, then common
48/44.1 kHz stereo float/PCM shared formats, and reports every attempted format
and HRESULT.

Gaming, Video, and Music presets change requested WASAPI buffering and quality
thresholds. Live capture counters and per-renderer fill, underrun, soft-resync,
and indicative drift telemetry feed a conservative Good / At risk / Degraded
status. The stability test evaluates the same measurements over 1, 5, or 10
minutes; it is not a laboratory latency measurement.

## Classification boundary

Endpoint IDs remain opaque. Classification uses documented endpoint properties
and a conservative Media/Hands-Free sibling-name heuristic. C++/WinRT enumerates
Bluetooth association endpoints and confirms their paired/connected state.
Correlation prefers a shared container ID and falls back to normalized physical
names when Windows omits it. `likely` remains a UX hint, not proof of
simultaneous A2DP capability.

## Failure model

- Inactive selections are rejected with currently usable alternatives.
- Every output is activated independently.
- Device invalidation is isolated to its renderer and retains the HRESULT.
- Other renderers continue when one device disappears.
- Cancellation is checked at 25 ms intervals; render-event waits are bounded.
- GUI and CLI report partial failure without claiming hardware compatibility.

## Real-time fanout and bounded synchronization

The v0.7 system-wide route uses one preallocated SPSC ring per renderer.
Capture sequence-guards and release-publishes complete 48 kHz stereo blocks;
each renderer acquire-loads its own cursor and verifies the guard around its
fixed-memory copy. Empty rings are zero-filled and full rings drop the oldest
complete block. The running path has no mutex, allocation, formatting, logging,
enumeration, UI operation, or ancillary clock query. See
[the real-time audit](realtime-audit.md).

Windows shared mode still owns endpoint format conversion, while the renderer
uses a bounded phase-continuous rate matcher to follow independent endpoint
clocks without allocating in the audio callback. Optional microphone-assisted
latency measurement remains a separate experiment.

Endpoint property notifications never launch inventory work. During routing,
noncritical topology changes are accumulated for one refresh after stop, while
a suspected selected-endpoint loss is confirmed by stable ID after a 1.5 second
control-plane debounce.

Virtual drivers, signing, APO deployment, and Auracast control remain outside
the user-mode MVP. SysVAD is an experiment reference, not a dependency.
