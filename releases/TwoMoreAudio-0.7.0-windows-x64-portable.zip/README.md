# TwoMore Audio

Portable Windows x64 build for routing one audio source to two or more
independently connected output devices.

## Start

1. Pair and connect the desired Bluetooth **Media** endpoints in Windows.
2. Run `twomore-gui.exe`.
3. Select the outputs and use **Test both headphones** before playing normal
   audio.
4. Use **Align** when one device is audibly ahead of the other.

The portable build does not install a driver or require an installer. Settings
and diagnostic logs are kept next to the executable. The optional command-line
checks are in `tools\twomore-cli.exe`; the main application is always
`twomore-gui.exe`.

```powershell
.\tools\twomore-cli.exe --help
```

## Support bundle

When reporting a problem, run this from the extracted folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\collect-support-bundle.ps1
```

The script creates a timestamped folder with diagnostics, the test report when
available, bounded application logs, and a SHA-256 manifest. It intentionally
does not copy settings, saved device identities, audio samples, or source code.
Review endpoint names and IDs before sharing the folder.

## What is included

- Multi-output rendering for Bluetooth, wired, USB, and HDMI endpoints.
- Per-device volume, mute, delay, activity, and quality indicators.
- Guided checks, saved stable-device selections, and alignment presets.
- Optional system-wide routing through a separately installed virtual cable.

For system-wide routing, install VB-CABLE or Voicemeeter separately from its
official vendor and follow the **System-wide** setup check. TwoMore Audio does
not bundle or install a virtual audio driver.

## Important limitations

Use the Bluetooth **Media** endpoint for music and video. Hands-Free endpoints
are intended for calls and commonly provide lower-quality mono audio. Independent
Bluetooth radios have their own clocks and buffering; TwoMore Audio follows
bounded drift and reports quality, but cannot promise perfect acoustic phase
alignment, codec selection, automatic pairing, or DRM bypass.

## Documentation

- [GUI guide](docs/gui.md)
- [System-wide routing](docs/systemwide.md)
- [Quality monitoring](docs/quality.md)
- [Troubleshooting](docs/troubleshooting.md)
- [Diagnostics and privacy](docs/diagnostics.md)
- [Release notes](docs/release-notes.md)

## Verify this build

The adjacent `.sha256` file verifies the ZIP. The JSON manifest records the
exact source revision and confirms that source code is not included.

This is proprietary software. See [LICENSE](LICENSE) and
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). The implementation source is
not distributed with the binary release.
